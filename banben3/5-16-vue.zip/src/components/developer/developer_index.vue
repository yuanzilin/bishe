<template>
  <div>
    <developer_header></developer_header>
  </div>
</template>

<script>
import developer_header from "@/components/developer/developer_header";
export default {
  name: "developer_index",
  components:{
    developer_header
  }
}
</script>

<style scoped>

</style>