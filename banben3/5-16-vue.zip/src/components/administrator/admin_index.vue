<template>
  <div>
    <admin_header></admin_header>
  </div>
</template>

<script>
import admin_header from "@/components/administrator/admin_header";
export default {
  name: "admin_index",
  components:{
    admin_header
  }
}
</script>

<style scoped>

</style>