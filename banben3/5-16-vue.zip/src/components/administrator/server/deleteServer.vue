<template>

</template>

<script>
export default {
  name: "deleteServer"
}
</script>

<style scoped>

</style>