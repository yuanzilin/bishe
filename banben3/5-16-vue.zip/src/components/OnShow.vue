<template>
    <div id = "onshow">

    </div>
</template>

<script>
export default {
    name:"OnShow"
}
</script>